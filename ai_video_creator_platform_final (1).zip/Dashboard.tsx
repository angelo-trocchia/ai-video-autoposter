import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';

const Dashboard = () => {
  const [videoTitle, setVideoTitle] = useState('');
  const [videoDescription, setVideoDescription] = useState('');
  const [hashtags, setHashtags] = useState('');
  const [videoFile, setVideoFile] = useState(null);
  const [status, setStatus] = useState('');

  const handleUpload = async (platform) => {
    if (!videoFile) return;

    const formData = new FormData();
    formData.append('video', videoFile);
    formData.append('title', videoTitle);
    formData.append('description', videoDescription);
    formData.append('hashtags', hashtags);

    const endpoint = platform === 'youtube' ? '/api/upload' : '/api/tiktok';
    const res = await fetch(endpoint, {
      method: 'POST',
      body: formData
    });

    const data = await res.json();
    setStatus(data.message || 'Upload complete');
  };

  return (
    <div className="p-4 grid gap-4">
      <h1 className="text-xl font-bold">AI Video Dashboard</h1>
      <Card>
        <CardContent className="grid gap-2">
          <input type="file" accept="video/*" onChange={e => setVideoFile(e.target.files[0])} />
          <input placeholder="Title" value={videoTitle} onChange={e => setVideoTitle(e.target.value)} />
          <input placeholder="Description" value={videoDescription} onChange={e => setVideoDescription(e.target.value)} />
          <input placeholder="Hashtags" value={hashtags} onChange={e => setHashtags(e.target.value)} />
          <div className="flex gap-2">
            <Button onClick={() => handleUpload('youtube')}>Post to YouTube</Button>
            <Button onClick={() => handleUpload('tiktok')}>Post to TikTok</Button>
          </div>
          <p>{status}</p>
        </CardContent>
      </Card>
    </div>
  );
};

export default Dashboard;
